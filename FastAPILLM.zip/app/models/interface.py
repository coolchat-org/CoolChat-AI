from pydantic import BaseModel


class SuccessResponse(BaseModel):
    response: str
    message: str

class ChatbotAttributeConfig(BaseModel):
    tone: str
    company: str
