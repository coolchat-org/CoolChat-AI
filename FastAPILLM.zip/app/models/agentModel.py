from typing import Annotated, Any, Dict, TypedDict, Optional, List
from langchain_core.messages import AIMessage, HumanMessage
from pydantic import BaseModel


# Define state schema
class AgentState(TypedDict):
    messages: List[HumanMessage | AIMessage]
    current_message: str
    should_create_transaction: bool
    transaction_data: Dict[str, Any] | None
    is_end: bool
    config: Dict[str, Any]
    session_id: str
    system_prompt: Optional[str]

class StreamingAgentResponse:
    def __init__(self, content: str, is_end: bool = False, is_chunk: bool = True):
        self.content = content
        self.is_end = is_end
        self.is_chunk = is_chunk

    def to_json(self):
        return {
            "content": self.content,
            "is_end": self.is_end,
            "is_chunk": self.is_chunk
        }
    
class ChatRequest(BaseModel):
    message: str
    session_id: Optional[str] = None  # Client gửi session_id để tiếp tục hội thoại
    org_db_host: Optional[str] = None

class Message(BaseModel):
    role: str  # "user" or "assistant"
    content: str

class ChatResponse(BaseModel):
    response: str
    is_end: bool = False
    session_id: str  # Trả về session_id cho client