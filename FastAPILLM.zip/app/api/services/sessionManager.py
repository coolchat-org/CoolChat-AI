from typing import Dict, Optional
import uuid
from app.models.agentModel import AgentState


class SessionManager:
    def __init__(self):
        self.sessions: Dict[str, AgentState]

    def create_session(self) -> str:
        session_id = str(uuid.uuid4())
        self.sessions[session_id] = {
            "messages": [],
            "is_end_conversation": False
        }
    
    def get_session(self, session_id: str) -> Optional[AgentState]:
        return self.sessions.get(session_id, None)
    
    def update_session(self, session_id: str, state: AgentState):
        self.sessions[session_id] = state

    def end_session(self, session_id: str):
        if session_id in self.sessions:
            del self.sessions[session_id]