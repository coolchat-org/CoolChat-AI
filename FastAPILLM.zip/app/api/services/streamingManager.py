import asyncio
from typing import Dict, List, Optional, AsyncGenerator
import uuid

class StreamingManager:
    """Quản lý streaming cho nhiều sessions"""
    def __init__(self):
        self.streams = {}  # session_id -> queue
    
    def create_stream(self, session_id: str) -> str:
        """Tạo stream mới cho session"""
        stream_id = str(uuid.uuid4())
        self.streams[stream_id] = asyncio.Queue()
        return stream_id
    
    async def add_chunk(self, stream_id: str, chunk: str):
        """Thêm chunk vào stream"""
        if stream_id in self.streams:
            await self.streams[stream_id].put({"type": "chunk", "content": chunk})
    
    async def add_final_state(self, stream_id: str, state: Dict):
        """Thêm final state vào stream"""
        if stream_id in self.streams:
            await self.streams[stream_id].put({"type": "final", "state": state})
            # Đánh dấu kết thúc stream
            await self.streams[stream_id].put(None)
    
    async def get_stream(self, stream_id: str) -> AsyncGenerator:
        """Generator để stream dữ liệu"""
        if stream_id not in self.streams:
            return
        
        while True:
            item = await self.streams[stream_id].get()
            if item is None:
                # Kết thúc stream
                del self.streams[stream_id]
                break
            
            yield item