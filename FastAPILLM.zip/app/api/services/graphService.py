import asyncio
from typing import Annotated, Any, Dict, TypedDict
import uuid
from langchain_openai import ChatOpenAI
from langgraph.graph import Graph, StateGraph, END
from langgraph.prebuilt import ToolExecutor
from langchain_core.messages import AIMessage, HumanMessage
from langchain_core.tools import tool
from langchain_core.prompts import ChatPromptTemplate, SystemMessagePromptTemplate
from app.models.agentModel import AgentState, ChatRequest, Message, ChatResponse
from langgraph.graph.message import add_messages
from app.dtos.chatUserDto import ChatUserDto
from app.core.config import settings


from app.api.services.chatService import (
    response_from_LLM,
    call_backend_transaction
)
from app.api.services.sessionManager import SessionManager
from app.models.interface import ChatbotAttributeConfig


# Tools definition
@tool("create_transaction")
def create_transaction(transaction_data: dict) -> str:
    """Create a backend transaction with the provided data"""
    try:
        result = call_backend_transaction(transaction_data)
        return f"Transaction created successfully: {result}"
    except Exception as e:
        return f"Failed to create transaction: {str(e)}"
    
@tool("end_conversation")
def end_conversation():
    """Create a backend transaction with the provided data"""
    try:
        return {
            "message": "END",
            "is_end": True
        }
    except Exception as e:
        return f"Failed to create transaction: {str(e)}"


class AgentService:
    def __init__(self):
        self.workflow = self._build_workflow()
        self.session_manager = SessionManager()
        self.tools = [end_conversation, create_transaction]
        self.llm = ChatOpenAI(model="gpt-4o-mini", temperature=0.3, api_key=settings.OPENAI_API_KEY, streaming=True).bind_tools(self.tools)
        self.system_prompt_template = """You are a helpful AI assistant for {company}. Your tone should be {tone}.

        After each response, you should decide if the conversation should end.

        If the user shows signs of wanting to end the conversation (saying goodbye, thank you, etc.) or if you've fully addressed their needs, use the end_conversation tool.
        
        Examples of when to end conversation:
        - User says: "goodbye", "bye", "thank you", "thanks"
        - User indicates they are satisfied and have no more questions
        - The conversation has reached a natural conclusion
        
        Otherwise, continue the conversation normally."""
    

    def _build_workflow(self):
        workflow = StateGraph(AgentState) 

        # Define nodes
        workflow.add_node("process_input", self._process_input)
        workflow.add_node("generate_response", self._generate_response)
        workflow.add_node("update_session", self._update_session)
        workflow.add_node("end_conversation", self._end_conversation)

        # Entry point => Handling input
        workflow.set_entry_point("process_input")
        # Định nghĩa các edges
        workflow.add_edge("process_input", "generate_response")
        workflow.add_edge("generate_response", "update_session")
        

        # Conditional edge từ update_session
        workflow.add_conditional_edges(
            "update_session",
            self._check_conversation_end,
            {
                "end": "end_conversation",
                "continue": END  # Kết thúc workflow sau mỗi lần xử lý
            }
        )

        workflow.add_edge("end_conversation", END)
        return workflow.compile()
    
    async def _process_input(self, state: AgentState):
        prompt_template = SystemMessagePromptTemplate.from_template(self.system_prompt_template)
        formatted_prompt = prompt_template.format(
            company=state["config"]["company"],
            tone=state["config"]["tone"]
        )

        print(formatted_prompt.content)
        # Cập nhật state
        return {
            "system_prompt": formatted_prompt.content,
            "messages": state["messages"],
            "session_id": state["session_id"],
            "is_end": False,
            "response": "",
            "is_streaming": True
        }

    async def _generate_response(self, state: AgentState):
        """Generate response with end conversation detection"""
        history = state["messages"].copy()
        user_input = history[-1].content
        session_id = state.get("session_id", "")
        db_host = state.get("db_host", "")
        
        # Tạo một future để nhận state cuối cùng
        final_state_future = asyncio.Future()
        
        # Callback để nhận state cuối cùng
        async def on_final_state(final_state):
            history.append(Message(
                role="assistant",
                content=final_state["messages"]
            ))
            final_state_future.set_result({
                "messages": history,
                "is_end": final_state["is_end"],
                **state  # Giữ lại các state khác
            })
        
        # Tạo task để xử lý streaming
        async def handle_streaming():
            # Tạo route endpoint cho streaming
            stream_id = f"stream_{session_id}_{uuid.uuid4()}"
            
            # Lưu stream_id vào state để frontend có thể truy cập
            state["stream_id"] = stream_id
            
            # Tạo một queue mới cho streaming
            streaming_queue = asyncio.Queue()
            
            # Xử lý response_from_LLM
            async for response in response_from_LLM(
                session_id, 
                query=user_input, 
                db_host=db_host,
                llm_with_tools=self.llm,
                system_prompt=state["system_prompt"],
                stream_callback=on_final_state
            ):
                # Đưa response vào queue
                await streaming_queue.put(response)
        
        # Tạo task để xử lý streaming
        streaming_task = asyncio.create_task(handle_streaming())
        
        # Đợi final state
        result = await final_state_future
        
        # Trả về state cho node tiếp theo
        return result


    def _update_session(self, state: AgentState):
        """Finalize conversation"""
        return state

    def _end_conversation(self, state: AgentState):
        """Finalize conversation"""
        print("End here!")
        self.create_backend_transaction()

    def _check_conversation_end(self, state: AgentState) -> str:
        """Routing logic based on state"""
        print("Routing...")
        print("State: ", state)
        route = "end" if state["is_end"] == True else "continue"
        print("Route: ", route)
        return route
    
    
    def create_backend_transaction(self):
        """Dummy transaction creation"""
        print("TRANSACTION CREATED")
